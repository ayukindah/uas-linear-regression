# LinearRegression_CarPrice
CarPrice Data set with categorical dataset 
Linear Regression on CarPrice dataset OR Encoding a categorical dataset in Linear Regression Algorithm.

https://medium.com/@madanflies/linear-regression-on-carprice-dataset-or-encoding-a-categorical-dataset-in-linear-regression-7378f207e5c1
